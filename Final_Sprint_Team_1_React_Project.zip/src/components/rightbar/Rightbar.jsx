import "./rightbar.css";
import { Redeem } from "@mui/icons-material";
import { Users } from "../../mockData";
import Online from "../online/Online";
import Profile from "../../pages/profile/Profile";

{
  /*Here we added some personal info to help fill in the profile page a bit more*/
}
{
  /*We could also store more user data in our mockData file to populate the correct*/
}
{
  /*information about a specific user, if we were setting this up for more than one user*/
}
export default function Rightbar({ profile }) {
  const HomeRightbar = () => {
    return (
      <>
        <div className="birthdayContainer">
          <Redeem className="birthdayImg" />
          <span className="birthdayMsg">
            <strong>Jack Spencer</strong> + <strong>4 others</strong> have a
            Birthday today!
          </span>
        </div>
        <img
          className="rightBarAd01"
          src="/assets/ads01.jpg"
          alt="Img Not Found"
        />
        <h4 className="rightBarTitle">Online Friends</h4>
        <ul className="rightBarFriendsList">
          {Users.map((u) => (
            <Online key={u.id} user={u} />
          ))}
        </ul>
      </>
    );
  };

  const ProfileRightbar = () => {
    return (
      <>
        <h4 className="rightbarTitle">
          <strong>User Information</strong>
        </h4>
        <div className="rightbarInfo">
          <div className="rightbarInfoItem">
            <span className="rightbarInfoKey">
              <strong>City:</strong>
            </span>
            <span className="rightbarInfoValue">Joe Bats Arm</span>
          </div>
          <div className="rightbarInfoItem">
            <span className="rightbarInfoKey">
              <strong>From:</strong>
            </span>
            <span className="rightbarInfoValue">Bay Bulls</span>
          </div>
          <div className="rightbarInfoItem">
            <span className="rightbarInfoKey">
              <strong>Relationship:</strong>
            </span>
            <span className="rightbarInfoValue">It's Complicated</span>
          </div>
        </div>
        <h4 className="rightbarTitle">
          <strong>Following:</strong>
        </h4>
        <div className="rightbarFollowings">
          <div className="rightbarFollowing">
            <img
              className="rightbarFollowingImg"
              src="assets/profile02.jpg"
              alt="Img Not Found"
            />
            <span className="rightbarFollowingName">
              <strong> Des Fella</strong>
            </span>
          </div>
        </div>
        <div className="rightbarFollowings">
          <div className="rightbarFollowing">
            <img
              className="rightbarFollowingImg"
              src="assets/profile02.jpg"
              alt="Img Not Found"
            />
            <span className="rightbarFollowingName">
              <strong> Des Fella</strong>
            </span>
          </div>
        </div>
        <div className="rightbarFollowings">
          <div className="rightbarFollowing">
            <img
              className="rightbarFollowingImg"
              src="assets/profile02.jpg"
              alt="Img Not Found"
            />
            <span className="rightbarFollowingName">
              <strong> Des Fella</strong>
            </span>
          </div>
        </div>
        <div className="rightbarFollowings">
          <div className="rightbarFollowing">
            <img
              className="rightbarFollowingImg"
              src="assets/profile02.jpg"
              alt="Img Not Found"
            />
            <span className="rightbarFollowingName">
              <strong> Des Fella</strong>
            </span>
          </div>
        </div>
      </>
    );
  };

  return (
    <div className="rightbar">
      <div className="rightBarWrapper">
        {/*This is a conditional statement created to determin which right bar*/}
        {/*to be loaded pending on what page the user is currently on*/}
        {profile ? <ProfileRightbar /> : <HomeRightbar />}
      </div>
    </div>
  );
}

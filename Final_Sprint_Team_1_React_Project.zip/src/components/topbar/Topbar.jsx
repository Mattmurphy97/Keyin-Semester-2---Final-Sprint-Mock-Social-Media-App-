import "./topbar.css";
import { Search, Person, Chat, Notifications } from "@mui/icons-material";

export default function Topbar() {
  {
    /*Here is our nav bar component, broken into Divs for easy styling*/
  }
  return (
    <div className="topBarContainer">
      <div className="topbarLeft">
        <a href="/home">
          {/*Here is a link to return to the feed page*/}
          <span className="logo ">New-Look Social Media</span>
        </a>
      </div>
      <div className="topbarCenter">
        <div className="searchBar">
          <Search className="searchIcon" />
          <input
            placeholder="Search For A Friend, Post, or Video"
            className="searchInput"
          />
        </div>
      </div>
      <div className="topbarRight">
        <div className="topbarLinks">
          <a href="/profile">
            <span className="topbarLink">
              <strong>HomePage</strong>
            </span>
          </a>
          <a href="/home">
            <span className="topbarLink">
              <strong>Timeline</strong>
            </span>
          </a>
        </div>
        <div className="topbarIcons">
          <div className="topbarIconItem">
            <Person />
            <span className="topbarIconBadge">1</span>
          </div>
          <div className="topbarIconItem">
            <Chat />
            <span className="topbarIconBadge">2</span>
          </div>
          <div className="topbarIconItem">
            <Notifications />
            <span className="topbarIconBadge">3</span>
          </div>
        </div>
        <a href="/profile">
          <img src="/assets/profile01.jpg" alt="" className="topbarImg" />
        </a>
      </div>
    </div>
  );
}

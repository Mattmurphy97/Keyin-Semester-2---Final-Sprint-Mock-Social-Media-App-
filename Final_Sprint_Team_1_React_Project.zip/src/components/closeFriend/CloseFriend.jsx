import "./closeFriend.css";

export default function CloseFriend(user) {
  return (
    <li className="sidebarFriend">
      {/*Again, ran into issues get the profile Imgs to display properly*/}
      <img
        className="sidebarFriendImg"
        src={user.profilePicture}
        alt="Img Not Found"
      />
      <span className="sidebarFriendName">{user.username}</span>
    </li>
  );
}

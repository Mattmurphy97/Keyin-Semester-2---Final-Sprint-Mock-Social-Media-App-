import "./online.css";

export default function Online(user) {
  {
    /*This is similar to the Close Friends component, didn't dive too far into*/
  }
  {
    /*this particular component */
  }
  return (
    <li className="rightBarFriend">
      <div className="rightBarProfileImgContainer">
        <img
          src={user.profilePicture}
          alt="Img Not Found"
          className="rightBarProfileImg"
        />
        <span className="rightBarOnline"></span>
      </div>
      <span className="rightBarUserName">
        {/*Here would be a looping system which reads out mockData and displays*/}
        {/*online friends similar to facebook messenger, if we had a chat/msg system in place*/}
        <strong>{user.username}Some Guy</strong>
      </span>
    </li>
  );
}

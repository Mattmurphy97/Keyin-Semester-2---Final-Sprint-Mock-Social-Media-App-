import "./post.css";
import { MoreVert, ThumbUp, Favorite } from "@mui/icons-material";
import { Users } from "../../mockData";
import { useState } from "react";

{
  /*Below is a method using JS to add or remove a like from our populated posts*/
}
{
  /*We use useState to modifiy the specific div of the post, and we used a boolian*/
}
{
  /*as our condition so we can only add/remove a like from a post once*/
}
export default function Post({ post }) {
  const [like, setLike] = useState(post.like);
  const [isLiked, setIsLiked] = useState(false);

  const likeHandler = () => {
    setLike(isLiked ? like - 1 : like + 1);
    setIsLiked(!isLiked);
  };

  return (
    <div className="post">
      <div className="postWrapper">
        <div className="postTop">
          <div className="postTopLeft">
            {/*Similar to how we grabbed our actual post data for our home screen, only*/}
            {/*here we add an index for profilePicture so we can have different users*/}
            {/*Below that, we use the same method for displaying the username*/}
            <img
              className="postProfileImg"
              src={Users.filter((u) => u.id === post.userId)[0].profilePicture}
              alt="Img Not Found"
            />

            <span className="postUserName">
              {Users.filter((u) => u.id === post.userId)[0].username}
            </span>
            <span className="postDate">{post.date}</span>
          </div>
          <div className="postTopRight">
            <MoreVert />
          </div>
        </div>
        <div className="postCenter">
          <span className="postText">{post.desc} </span>
          <img className="postImg" src={post.photo} alt="Img Not Found" />
        </div>
        <div className="postBottom">
          <div className="postBottomLeft">
            {/*Here is the onClick command using our fucntion created above*/}
            <ThumbUp className="likeBtn" onClick={likeHandler} />
            <Favorite className="likeBtn" onClick={likeHandler} />
            <span className="postLikeCounter">{like} People Liked This!</span>
          </div>
          <div className="postBottomRight">
            <span className="postCommentText">{post.comment} Comments!</span>
          </div>
        </div>
      </div>
    </div>
  );
}

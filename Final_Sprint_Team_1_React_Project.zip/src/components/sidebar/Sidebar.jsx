import "./sidebar.css";
import {
  RssFeed,
  Chat,
  PlayCircle,
  Groups,
  Bookmark,
  HelpOutline,
  Work,
  CalendarMonth,
  School,
} from "@mui/icons-material";
import { Users } from "../../mockData";
import CloseFriend from "../closeFriend/CloseFriend";

{
  /*Below are the imports for our side (leftside) bar. Instead of using a bunch*/
}
{
  /*of jpgs, we decided to use more modern style Icons by importing them from*/
}
{
  /*"@mui/icons-material" and resizing them accordingly using CSS.*/
}
{
  /*Also, here we import our info from the mockData js file.*/
}

export default function Sidebar() {
  return (
    <div className="sidebar">
      <div className="sidebarWrap">
        <ul className="sidebarList">
          <li className="sidebarListItem">
            <RssFeed className="sidebarIcon" />
            <span className="sidebarListItemText">My Feed</span>
          </li>
          <li className="sidebarListItem">
            <Chat className="sidebarIcon" />
            <span className="sidebarListItemText">Chat</span>
          </li>
          <li className="sidebarListItem">
            <PlayCircle className="sidebarIcon" />
            <span className="sidebarListItemText">Videos</span>
          </li>
          <li className="sidebarListItem">
            <Groups className="sidebarIcon" />
            <span className="sidebarListItemText">Groups</span>
          </li>
          <li className="sidebarListItem">
            <Bookmark className="sidebarIcon" />
            <span className="sidebarListItemText">Bookmarks</span>
          </li>
          <li className="sidebarListItem">
            <HelpOutline className="sidebarIcon" />
            <span className="sidebarListItemText">Questions</span>
          </li>
          <li className="sidebarListItem">
            <Work className="sidebarIcon" />
            <span className="sidebarListItemText">Jobs</span>
          </li>
          <li className="sidebarListItem">
            <CalendarMonth className="sidebarIcon" />
            <span className="sidebarListItemText">Events</span>
          </li>
          <li className="sidebarListItem">
            <School className="sidebarIcon" />
            <span className="sidebarListItemText">Courses</span>
          </li>
        </ul>
        <button className="sidebarBtn">Show More</button>
        <hr className="sidebarHr" />
        <ul className="sidebarFriendList">
          {/*Here we use the map function to pull our data from mockData using*/}
          {/*key and the user id, which will loop to display a users main friends*/}
          {/*Idealy we would have an object key which would contain a value that*/}
          {/*would indicate if specific friends are online or not, and display it here*/}
          {/*Ran into an issue that prevented the Img to display!*/}
          {Users.map((u) => (
            <CloseFriend key={u.id} user={u} />
          ))}
        </ul>
      </div>
    </div>
  );
}

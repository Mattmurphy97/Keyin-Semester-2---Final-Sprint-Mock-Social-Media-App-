import Share from "../share/Share";
import Post from "../post/Post";
import "./feed.css";
import { Posts } from "../../mockData";

export default function Feed() {
  return (
    <div className="feed">
      <div className="feedWrapper">
        <Share />
        {/*For Each post, return a post specificed by the KEY (id) */}
        {/*This will populate our Feed page with our post component which pulls*/}
        {/*the data from */}
        {Posts.map((p) => (
          <Post key={p.id} post={p} />
        ))}
      </div>
    </div>
  );
}

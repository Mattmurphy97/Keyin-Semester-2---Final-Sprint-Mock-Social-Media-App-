import "./share.css";
import {
  AddPhotoAlternate,
  Tag,
  EditLocation,
  EmojiEmotions,
} from "@mui/icons-material";

{
  /*This component is used at the top of the feed/profile page, this allowes the*/
}
{
  /*user to share/post at the post page AND their own profile page*/
}
export default function Share() {
  return (
    <div className="share">
      <div className="shareWrapper">
        <div className="shareTop">
          <img
            className="shareProfileImg"
            src="/assets/profile01.jpg"
            alt="Img Not Found"
          />
          <input placeholder="What's on your mind?" className="shareInput" />
        </div>
        <hr className="shareHr" />
        <div className="shareBottom">
          <div className="shareOptions">
            <div className="shareOption">
              <AddPhotoAlternate
                className="shareIcon"
                htmlColor="forestGreen"
              />
              <span className="shareOptionText">Photo or Video</span>
            </div>
            <div className="shareOption">
              <Tag className="shareIcon" htmlColor="forestGreen" />
              <span className="shareOptionText">Tag A Friend</span>
            </div>
            <div className="shareOption">
              <EditLocation className="shareIcon" htmlColor="forestGreen" />
              <span className="shareOptionText">Add Location</span>
            </div>
            <div className="shareOption">
              <EmojiEmotions className="shareIcon" htmlColor="forestGreen" />
              <span className="shareOptionText">Add Mood</span>
            </div>
          </div>
          <button className="shareBtn">Share!</button>
        </div>
      </div>
    </div>
  );
}

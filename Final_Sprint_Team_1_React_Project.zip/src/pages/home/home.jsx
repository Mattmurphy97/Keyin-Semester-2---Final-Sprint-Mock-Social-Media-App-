import Topbar from "../../components/topbar/Topbar";
import Sidebar from "../../components/sidebar/Sidebar";
import Feed from "../../components/feed/Feed";
import Rightbar from "../../components/rightbar/Rightbar";
import "./home.css";

export default function home() {
  return (
    <>
      <Topbar />
      <div className="homeContainer">
        {/*For the log in button, the "feed" page will be populated by other components*/}
        {/*as seen below*/}
        <Sidebar />
        <Feed />
        <Rightbar />
      </div>
    </>
  );
}

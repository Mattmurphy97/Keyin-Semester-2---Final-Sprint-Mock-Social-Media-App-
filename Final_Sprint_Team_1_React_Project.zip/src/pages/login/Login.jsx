//Routes/useNavigate imported here while trying a few methods to implement links
import { Routes, Route, useNavigate } from "react-router-dom";
import "./login.css";

export default function Login() {
  const nav = useNavigate();
  //Here is the login screen. Normally this would function by using the mockData
  //to store username/password to log in along with a reg. page for new users.
  return (
    <div className="login">
      <div className="loginWrapper">
        <div className="loginLeft">
          <img src="" alt="" />
          <h3 className="loginLogo">LOGIN HERE</h3>
          <span className="loginDesc"> Give Yourself a New Look! </span>
        </div>
        <div className="loginRight">
          <div className="loginBox">
            <input placeholder="Email" className="loginInput" />
            <input placeholder="Password" className="loginInput" />
            <div className="loginBtn">
              {/*This was the temp fix for the Link issues*/}
              <a href="/home">
                <button className="loggedIn">
                  <strong>Log In</strong>
                </button>
              </a>
            </div>
            <button className="loginForgot">
              {/*Below this is where we would implement our pages for new users*/}
              {/*And a design for users who forgot their passwords*/}
              <strong>Forgot Password?</strong>
            </button>
            <button className="loginRegisterBtn">
              <strong>Create New Account</strong>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

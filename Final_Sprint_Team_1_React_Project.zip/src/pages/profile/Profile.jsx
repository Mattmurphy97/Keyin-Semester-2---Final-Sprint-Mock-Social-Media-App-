import "./profile.css";
import Topbar from "../../components/topbar/Topbar";
import Sidebar from "../../components/sidebar/Sidebar";
import Feed from "../../components/feed/Feed";
import Rightbar from "../../components/rightbar/Rightbar";

{
  /*Here would be the profile page which shows the correct right bar component*/
}
{
  /*Normally this would be populated with post ONLY from the user (or others sharing)*/
}
{
  /*to their profile page), but for display purposes we just looped the same data*/
}
{
  /*we used in the Feed page*/
}
export default function Profile() {
  return (
    <>
      <Topbar />
      <div className="homeContainer">
        <Sidebar />
        <div className="profileRight">
          <div className="profileRightTop">
            <div className="profileCover">
              <img
                className="profileCoverImg"
                src="assets/Cover01.jpg"
                alt="Img Not Found"
              />
              <img
                className="profileUserImg"
                src="assets/profile01.jpg"
                alt="Img Not Found"
              />
            </div>
            <div className="profileInfo">
              <h4 className="profileInfoName">PROFILE NAME</h4>
              <span className="profileInfoDesc">PROFILE description</span>
            </div>
          </div>
          <div className="profileRightBottom">
            <Feed />
            <Rightbar profile />
          </div>
        </div>
      </div>
    </>
  );
}

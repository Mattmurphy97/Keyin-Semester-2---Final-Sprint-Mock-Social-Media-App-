import Home from "./pages/home/home";
import Profile from "./pages/profile/Profile";
import Login from "./pages/login/Login";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

//Below is the Routes/Links for React, Login will be our homepage.
export default function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Login />} />
        <Route path="/home" element={<Home />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
    </Router>
  );
}
//Ran into some issues to implement <Link>, spoke to a few KPMs but still ran
//into a few problems. Used <a href> just to make the pages of the site accessible
//during navigation

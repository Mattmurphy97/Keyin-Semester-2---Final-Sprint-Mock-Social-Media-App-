/*General Imports*/
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

//var container to access root
//var root for reactDom

const container = document.getElementById("root");
const root = ReactDOM.createRoot(container);
// This renders the App.js
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById("root")
);

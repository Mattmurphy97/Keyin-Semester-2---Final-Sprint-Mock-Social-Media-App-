export const Users = [
  {
    id: 1,
    profilePicture: "assets/profile01.jpg",
    username: "Jimmy Jacobs",
  },
  {
    id: 2,
    profilePicture: "assets/profile02.jpg",
    username: "Some Guy",
  },
  {
    id: 3,
    profilePicture: "assets/profile03.jpg",
    username: "Trina Matthews",
  },
  {
    id: 4,
    profilePicture: "assets/profile04.jpg",
    username: "Leslie Oak",
  },
];

export const Posts = [
  {
    id: 1,
    desc: "Couldn't be Happier!!",
    photo: "assets/Post01.jpg",
    date: "2 Minutes Ago",
    userId: 1,
    like: 15,
    comment: 4,
  },
  {
    id: 2,
    desc: "YES PLEASE :P",
    photo: "assets/Post02.jpg",
    date: "14 Minutes Ago",
    userId: 2,
    like: 32,
    comment: 10,
  },
  {
    id: 3,
    desc: "THIS!",
    photo: "assets/Post03.jpg",
    date: "54 Minutes Ago",
    userId: 3,
    like: 106,
    comment: 40,
  },
  {
    id: 4,
    desc: "Love you girl!",
    photo: "assets/Post04.jpg",
    date: "1 Hour Ago",
    userId: 4,
    like: 143,
    comment: 55,
  },
];
